package com.example.pehgy.recyclerview

data class Info(val infotitle: String, val infocontent: String)